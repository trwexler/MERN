// import React, {useState} from 'react';


// const DisplayTasks = (props) =>{

//     const {allTasks, setAllTasks, currentIndex, setCurrentIndex} = props;



//     return(
//         <div>

//         </div>
//     )
// }


// export default DisplayTasks;