import React, {useState} from 'react';

const Tasks = (props) =>{

    const {allTasks, setAllTasks} = props;
    const [taskText, setTaskText] = useState("");
    const [index, setIndex] = useState(0);

    


    const handleSubmit = (e)=>{
        e.preventDefault();
        const fullTaskList = [...allTasks, {text: taskText, completed:false, id:index}];
        setAllTasks(fullTaskList); 
        setTaskText("");
        setIndex(index +1);
    }



    const styleTab = (completed)=>{         
        if(completed === true){
            return "completed";
        }
        else{
            return "notCompleted";
        }
    }
    


    const handleRemoveItem = text => {
        setAllTasks(allTasks.filter(task => task.text !== text))
    }



    const checkedBox = ()=>{
        allTasks.completed = !allTasks.completed;
        setAllTasks([...allTasks]);
    }
     

    return(
        <div>
            <form onSubmit={handleSubmit}>
                <input type="text"
                name="taskText"
                value={taskText}
                onChange={(e)=>setTaskText(e.target.value)}
                />
 
                <button>Add/Update!</button>
        
            </form>


{       
    allTasks.map((task,i)=>(
            <div key={i}>
                <div className={ styleTab(task.completed)}>{task.text}</div>
                <button onClick={()=>{(task.completed = true)}}>Completed</button>
                <button onClick={()=>handleRemoveItem(task.text)}>Remove</button>

            </div>
        ))
}  

        </div>
    )
}

//i couldnt get any sort of index to work to be able to call individual items in the array, so I was unable to include a check box that dynamically altered the completed property.


export default Tasks;




// import React, {useState} from 'react';

// const Tasks = (props) =>{

//     // let newTaskText = "";
//     // let newTask = {completed: false, task:""};

//     // const handleChange = (e)=>{
//     //     newTask.task = e.target.value;
//     // }

//     // const addTask = ()=>{
//     //     setCurrentIndex(currentIndex + 1);
//     //     // setAllTasks(newTask);
//     //     setAllTasks({completed: false, task:""});
//     //     console.log(allTasks);
//     //     console.log(currentIndex);
//     //     // console.log(newTaskText);
//     // }

//     const {allTasks, setAllTasks, currentIndex, setCurrentIndex} = props;
//     const [taskText, setTaskText] = useState("");


//     const handleSubmit = (e)=>{
//         e.preventDefault();
//         const fullTaskList = [...allTasks, {text: taskText, completed:false, index:currentIndex}];
//         setAllTasks(fullTaskList); 
//         setCurrentIndex(currentIndex +1);
//     }


//     const remover = () =>{
//        const deletedList = [...allTasks, {text: taskText, completed:true, index:currentIndex}];
      
//        let filteredList = allTasks.filter((task) => (
//        task.completed === false))

//        setAllTasks([...filteredList]);
//     }

//     const styleTab = (completed)=>{         
//         if(completed === true){
//             return "completed";
//         }
//         else{
//             return "notCompleted";
//         }
//     }





//     return(
//         <div>
//             <form onSubmit={handleSubmit}>
//                 <input type="text"
//                 name="taskText"
//                 value={taskText}
//                 onChange={(e)=>setTaskText(e.target.value)}
//                 />
 
//                 <button>Add</button>
        
//             </form>


// {       
//     allTasks.map((task,i)=>(
//             <div key={i}>
//                 <div className={ styleTab(task.completed)}>{task.text}</div>
//                 <button onClick={()=>{(task.completed = true)}}>X</button>
//                 <button onClick={() =>remover(task)}>Delete</button>
//             </div>
//         ))
// }  

//         </div>
//     )
// }


// export default Tasks;
